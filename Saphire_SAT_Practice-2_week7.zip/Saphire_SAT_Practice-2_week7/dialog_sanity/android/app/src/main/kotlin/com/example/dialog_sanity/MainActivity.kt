package com.example.dialog_sanity

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
